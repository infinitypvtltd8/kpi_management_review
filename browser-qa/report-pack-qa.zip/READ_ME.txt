KPI MANAGEMENT REVIEW - REPORT PACK
=============================================

Generated at (UTC): 2026-11-10T02:19:31.941Z

Last Sheet check (UTC): 2026-11-10T02:19:29.099Z

Scope: Both companies · whole group

Period: All available months (union of months in scope)

Scope rules: Includes all departments and employees; company, department and employee filters are ignored.

Source status: 10 live; 0 stale; 0 unavailable; 0 loading

Privacy: This file may contain employee and financial information. Keep it private. Do not upload report packs, workbooks or CSV files to a public GitHub repository.

Snapshot: These reports are generated in the browser from the latest available in-session data. They do not update after download. Refresh the dashboard and export again for new data.

Missing and unavailable: A missing row or unavailable tab is not zero performance. Source connection status and last successful load are included. A stale tab contains an earlier in-session copy.

Year: Month headings without a year remain unspecified. Calendar order is not confirmed chronology.

Performance: Recorded percentages are unweighted averages of usable reported percentages and compatible actual/target ratios. Different KPIs have different meanings; comparisons are indicative, not like-for-like rankings. Percent values are expressed as 85.1 for 85.1%.

Assessment: Met rate is met divided by assessed records; unassessed rows are not counted as failures. Calculated status assumes higher numeric actual is better.

Duplicate and conflict: Duplicate month sections are visible in detail but excluded from all totals. Conflicting percentages are excluded from averages; conflicting statuses are excluded from assessed totals.

Movement: Movement requires unique matching employee/KPI names, consecutive month labels and the same score basis. The preceding month can be outside the report range; changes are in percentage points.

Projection: A simple linear extrapolation of at least three matched KPI pairs, clipped at zero. It is illustrative only and is not a prediction or confidence estimate.

Department ownership: X GUARD departments use single KPI ownership to prevent double counting. Uthpala is on both Admin and HR rosters but recruitment KPIs belong to HR & Recruitment; Nimmi heads Admin, HR and Finance and leadership KPIs are kept separate.

Units and work themes: Review groups are based on supplied roles. Work themes are keyword inferred and should be confirmed; neither is an official unit field from the Sheet.

Report coverage: All reports are based on data in the currently published employee tabs. Categories not present in the Sheet are not fabricated. Empty reports contain headers only.

Excel cell limit: Excel supports a maximum of 32,767 characters per cell. Longer text is truncated in the workbook; individual CSVs retain full text.

CSV safety: Text beginning with common spreadsheet formula prefixes is prefixed with an apostrophe for safety. Numeric values remain numeric.

Report: Executive summary: 10 rows. Counts include only available live or marked-stale source data. An empty percentage is not zero performance.

Report: People performance: 50 rows. Unavailable tabs are unknown, not zero; rows found in duplicate sections are excluded from totals.

Report: Department performance: 25 rows. X GUARD only. Uthpala’s recruitment KPIs belong to HR & Recruitment; Nimmi’s leadership KPIs are separate. Roster membership can overlap.

Report: Units & review groups: 30 rows. Role-based review groups are derived from the supplied structure, not an official unit column in the Sheet.

Report: Subsidiary comparison: 5 rows. Company KPI definitions and sample sizes differ, so this is not a like-for-like ranking.

Report: Complete KPI records: 274 rows. Includes duplicate and conflicting records for audit. See the two inclusion columns before using a record in aggregates.

Report: Attention & follow-up: 161 rows. A follow-up item is not an assigned task. No due dates, owners or corrective actions are invented.

Report: KPI movement: 120 rows. Only one-to-one employee/KPI matches with the same score basis are compared. The previous period can lie outside the selected export range.

Report: Work themes: 54 rows. Themes are inferred by keywords and are not official business-unit allocations. Duplicates are excluded.

Report: Reporting coverage: 50 rows. A missing row is shown explicitly. An unavailable tab is unknown; stale data is identified and may be incomplete.

Report: Data-quality checks: 32 rows. Issues are based on the selected scope and period. A connection issue is listed once per affected person.

Report: Source connections: 10 rows. Connection and loaded-row totals describe the browser session. Last successful data may be stale, not live.

Report: Roster & ownership: 10 rows. The roster and role structure are based on supplied information. Roster department membership can overlap; KPI ownership is single-counted.

Report: Illustrative projection: 10 rows. A simple extrapolation from at least three matched employee/KPI pairs, clipped at zero. It is illustrative, not a prediction or confidence estimate.

Tab: APEIRO / Sumudu: Live; last successful load (UTC): 2026-11-10T02:19:29.099Z

Tab: APEIRO / Heshani: Live; last successful load (UTC): 2026-11-10T02:19:29.099Z

Tab: APEIRO / Steve: Live; last successful load (UTC): 2026-11-10T02:19:29.099Z

Tab: X GUARD / Dewapriya: Live; last successful load (UTC): 2026-11-10T02:19:29.099Z

Tab: X GUARD / Malintha: Live; last successful load (UTC): 2026-11-10T02:19:29.099Z

Tab: X GUARD / Geeth: Live; last successful load (UTC): 2026-11-10T02:19:29.099Z

Tab: X GUARD / Uthpala Chandrasekara: Live; last successful load (UTC): 2026-11-10T02:19:29.099Z

Tab: X GUARD / Ramal: Live; last successful load (UTC): 2026-11-10T02:19:29.099Z

Tab: X GUARD / Ravira: Live; last successful load (UTC): 2026-11-10T02:19:29.099Z

Tab: X GUARD / Nimmi: Live; last successful load (UTC): 2026-11-10T02:19:29.099Z
